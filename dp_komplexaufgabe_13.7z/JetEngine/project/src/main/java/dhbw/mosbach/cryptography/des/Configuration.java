package dhbw.mosbach.cryptography.des;
public enum Configuration {
    INSTANCE;

    public final String secretKey = "dhbw2024*";
    public final String salt = "mghmos";
}