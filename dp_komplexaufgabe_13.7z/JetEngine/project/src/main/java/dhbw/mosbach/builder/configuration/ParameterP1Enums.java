package dhbw.mosbach.builder.configuration;

public enum ParameterP1Enums {
    ENABLED, DISABLED;

}