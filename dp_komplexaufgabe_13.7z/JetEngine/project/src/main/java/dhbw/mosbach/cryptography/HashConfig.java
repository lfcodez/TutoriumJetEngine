package dhbw.mosbach.cryptography;

public enum HashConfig {
    INSTANCE;

    private final String key = "asdfgh345654gdfsdsSAGHD";

    public String getKey() {
        return key;
    }
}
