package dhbw.mosbach.proxy;

public interface IConfigurationRO {
    String readAttributes();
}
