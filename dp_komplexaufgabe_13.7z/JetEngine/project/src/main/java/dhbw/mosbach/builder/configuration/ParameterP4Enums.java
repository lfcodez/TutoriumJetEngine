package dhbw.mosbach.builder.configuration;

public enum ParameterP4Enums {
    A, B, C
}