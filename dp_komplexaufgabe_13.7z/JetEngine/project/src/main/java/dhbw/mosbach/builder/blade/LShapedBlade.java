package dhbw.mosbach.builder.blade;

public class LShapedBlade extends Blade {
    public LShapedBlade(double weight) {
        super(weight);
        setShape(BladeShape.L);
    }
}