package dhbw.mosbach.builder.blade;

public enum BladeShape {
    S, L, R
}