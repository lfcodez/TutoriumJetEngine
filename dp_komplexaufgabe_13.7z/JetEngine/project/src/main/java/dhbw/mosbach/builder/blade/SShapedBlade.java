package dhbw.mosbach.builder.blade;

public class SShapedBlade extends Blade {
    public SShapedBlade(double weight) {
        super(weight);
        setShape(BladeShape.S);
    }
}