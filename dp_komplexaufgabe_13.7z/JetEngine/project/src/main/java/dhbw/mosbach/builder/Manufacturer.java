package dhbw.mosbach.builder;

public enum Manufacturer {
    RollsRoyce, PrattWhitney, GeneralElectric
}