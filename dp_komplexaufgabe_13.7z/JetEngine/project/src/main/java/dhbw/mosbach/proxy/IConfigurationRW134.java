package dhbw.mosbach.proxy;

import dhbw.mosbach.builder.configuration.ParameterP4Enums;

public interface IConfigurationRW134 extends IConfigurationRW13{

    void setP4(ParameterP4Enums parameterP4Enums);

}
