package dhbw.mosbach.builder.turbine;

import dhbw.mosbach.visitor.IEnginePart;

public interface ITurbine extends IEnginePart {
}
