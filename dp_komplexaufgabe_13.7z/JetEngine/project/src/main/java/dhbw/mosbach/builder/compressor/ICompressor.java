package dhbw.mosbach.builder.compressor;

import dhbw.mosbach.visitor.IEnginePart;

public interface ICompressor extends IEnginePart {
}
