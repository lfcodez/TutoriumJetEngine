package dhbw.mosbach.cryptography.aes;

public enum Configuration {
    INSTANCE;

    public final String secretKey = "dhbw2024*";
    public final String salt = "mghmos";
}