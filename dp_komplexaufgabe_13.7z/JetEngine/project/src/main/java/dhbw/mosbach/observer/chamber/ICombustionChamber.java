package dhbw.mosbach.observer.chamber;

import dhbw.mosbach.visitor.IEnginePart;

public interface ICombustionChamber extends IEnginePart {
}
