package dhbw.mosbach.builder;

public enum Model {
    Trent900, TrentXWB, Trent1000, F135, GE90
}