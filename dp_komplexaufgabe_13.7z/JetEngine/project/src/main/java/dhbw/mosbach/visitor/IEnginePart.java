package dhbw.mosbach.visitor;

public interface IEnginePart {
    public void accept(ITechnician technician);
}
