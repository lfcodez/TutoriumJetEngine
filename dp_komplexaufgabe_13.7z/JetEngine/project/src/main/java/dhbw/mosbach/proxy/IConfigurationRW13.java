package dhbw.mosbach.proxy;

import dhbw.mosbach.builder.configuration.ParameterP1Enums;

public interface IConfigurationRW13 extends IConfigurationRO{

    void setP1(ParameterP1Enums parameterP1Enums);

    void setP3(Boolean b);

}
