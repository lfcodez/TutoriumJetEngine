package dhbw.mosbach.cryptography;

public interface IHash {

    public String hash(String cipher, String secretKey);
}
