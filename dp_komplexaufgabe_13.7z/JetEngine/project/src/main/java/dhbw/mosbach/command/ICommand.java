package dhbw.mosbach.command;

public interface ICommand {
    public void execute();
}
