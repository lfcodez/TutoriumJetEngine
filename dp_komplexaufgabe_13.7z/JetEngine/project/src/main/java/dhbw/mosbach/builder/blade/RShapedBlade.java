package dhbw.mosbach.builder.blade;

public class RShapedBlade extends Blade {
    public RShapedBlade(double weight) {
        super(weight);
        setShape(BladeShape.R);
    }
}