package dhbw.mosbach.adapter;

public interface IConnector {
    Pin[] getData();
}
