package dhbw.mosbach.observer;

public interface IOverheatListener {
    public void overheated();
}
